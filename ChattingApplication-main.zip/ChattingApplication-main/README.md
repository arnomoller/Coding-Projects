# ChattingApplication
A group project for a chatting application for the final year module Enterprise Programming in C# (ITEHA3-B33).

Group Members:
Arno Moller cc96zrrs5
Lea Thumbiran LMTPQFTH6
